INSERT INTO role (id, description, name) VALUES (2, 'Admin role', 'ADMIN');
INSERT INTO role (id, description, name) VALUES (3, 'User role', 'USER');
