package com.vikramhome.config;

import java.io.IOException;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.web.filter.OncePerRequestFilter;

import com.vikramhome.model.User;
import com.vikramhome.model.UserToken;
import com.vikramhome.service.UserService;

import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.SignatureException;

public class JwtAuthenticationFilter extends OncePerRequestFilter {

	@Value("${jwt.header.string}")
	public String HEADER_STRING;

	@Value("${jwt.token.prefix}")
	public String TOKEN_PREFIX;

	@Resource(name = "userService")
	private UserDetailsService userDetailsService;

	@Autowired
	private UserService userService;

	@Autowired
	private TokenProvider jwtTokenUtil;

	@Override
	protected void doFilterInternal(HttpServletRequest req, HttpServletResponse res, FilterChain chain)
			throws IOException, ServletException {
		String header = req.getHeader(HEADER_STRING);
		String username = null;
		String authToken = null;
		if (null != header && header.startsWith(TOKEN_PREFIX)) {
			authToken = header.replace(TOKEN_PREFIX, "");
			try {
				username = jwtTokenUtil.getUsernameFromToken(authToken);
			} catch (IllegalArgumentException e) {
				logger.error("An error occurred while fetching Username from Token", e);
			} catch (ExpiredJwtException e) {
				logger.error("The token has expired", e);
			} catch (SignatureException e) {
				logger.error("Authentication Failed. Username or Password not valid.");
			} catch (Exception e) {
				logger.fatal(e.getMessage());
			}
		} else 
			logger.warn("Couldn't find bearer string, header will be ignored");
		
		if (null != username && null != SecurityContextHolder.getContext().getAuthentication()) {
			UserDetails userDetails = userDetailsService.loadUserByUsername(username);
			if (jwtTokenUtil.validateToken(authToken, userDetails)) 
				setSecurityContext(req, username, authToken, userDetails);			
		}
		chain.doFilter(req, res);
	}

	private void setSecurityContext(HttpServletRequest req, String username, String authToken,
			UserDetails userDetails) {
		UsernamePasswordAuthenticationToken authentication = jwtTokenUtil.getAuthenticationToken(authToken,
				SecurityContextHolder.getContext().getAuthentication(), userDetails);
		authentication.setDetails(new WebAuthenticationDetailsSource().buildDetails(req));
		logger.info("authenticated user " + username + ", setting security context");

		User user = userService.findOne(username);
		if (null != user) {
			List<UserToken> userTokenList = userService.findList(user.getId());
			for (UserToken token : userTokenList) {
				if (token.getActive().equalsIgnoreCase("Y")) {
					SecurityContextHolder.getContext().setAuthentication(authentication);
					break;
				}
			}
		}
	}
}