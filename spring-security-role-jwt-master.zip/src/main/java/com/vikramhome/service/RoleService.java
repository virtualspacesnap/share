package com.vikramhome.service;

import com.vikramhome.model.Role;

public interface RoleService {
    Role findByName(String name);
}
