package com.vikram.home.springboot;

import java.util.Arrays;
import java.util.List;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.vikram.home.springboot.entity.ApplicationUser;
import com.vikram.home.springboot.repository.UserRepository;

@SpringBootApplication
public class SpringbootApplication {
	
	@Autowired
	private UserRepository repository;

	@PostConstruct
	public void init(){
		List<ApplicationUser> list = Arrays.asList(
				new ApplicationUser(101, "Vikram", "p@gmail.com", "app123"),
				new ApplicationUser(102, "Rohan", "d@gmail.com", "app123"),
				new ApplicationUser(103, "Guddu", "l@gmail.com", "app123"),
				new ApplicationUser(104, "Nemo", "s@gmail.com", "app123"));		
		repository.saveAll(list);
	}

	public static void main(String[] args) {
		SpringApplication.run(SpringbootApplication.class, args);
	}

}
