package com.vikram.home.springboot.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.vikram.home.springboot.entity.ApplicationUser;

//@RepositoryRestResource(collectionResourceRel = "users",path = "users")
@Repository
public interface UserRepository extends JpaRepository<ApplicationUser, Integer> {
//PagingAndSortingRepository<ApplicationUser,Integer> {

    //public ApplicationUser findByEmail(@Param("email") String email);
	
	ApplicationUser findByName(String name);
}
