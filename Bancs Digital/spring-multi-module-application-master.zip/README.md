# spring-multi-module-application
Digital Demo : C:\Vikram_Personsal\Learning\VANILA\spring-multi-module-application-master

# command prompt build selective modules
mvn clean install --projects :service,:web

# command prompt build selective modules with dependent modules
mvn clean install --projects :service,:web -am
