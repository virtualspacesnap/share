package com.digital.mailservice;

import org.springframework.stereotype.Service;

@Service
public class EmailService {


    public void sendEMail(){
        System.out.println("Email service working !!");
    }
}
