package com.digital.common.exception;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.type.CollectionType;


/**
 * Default Class for this project
 * 
 * @author TCS
 *
 */
public interface ExceptionUtilApplication {

	public enum ApiExceptionTypes {
		ApiServiceException, ApiBusinessError, ApiDBException
	}
	
	Logger logger = LogManager.getLogger(ExceptionUtilApplication.class);
	Level DBERR_PUSH = Level.forName("DBERR_PUSH", 50);
		
	@SuppressWarnings({ "rawtypes", "unchecked" })
	default <T> T doRestExchange(String url, HttpMethod method, Object request, Class<T> responseType,
			HttpHeaders headers, RestTemplate restTemplate, Map<String,Object> params) throws Exception {
		ResponseEntity<T> response = null;
		Logger log = params.containsKey("LOGGER") ? (Logger) params.get("LOGGER") : logger;
		String enablerName = null;
		String serviceName = null;
		String exceptionType = null;
		String customErrorMessage = null;
		
		if (!this.validCall(params))
			throw new Exception("Mandatory params missing");
		
		try {			
			enablerName = (String) params.get("COMPONENT_NAME");
			serviceName = (String) params.get("SERVICE_NAME");
			exceptionType = (String) params.get("EXCEPTION_TYPE");
			customErrorMessage = (String) params.get("CUSTOM_ERROR_MSG");		
			
			HttpEntity entity = request != null ? new HttpEntity(request, headers) : new HttpEntity(headers);
			response = restTemplate.exchange(url, method, entity, responseType);
			return response.getBody();
		} catch (HttpStatusCodeException e) {
			log.error(new StringBuilder("STATUS").append(e.getRawStatusCode()).toString(), e);
			log.error(new StringBuilder("RESPONSE").append(e.getResponseBodyAsString()).toString());
			final String fullErrorMsg =  e.getResponseBodyAsString();
			log.log(DBERR_PUSH, fullErrorMsg);
			ApiExceptionTypes exceptionTypeName = ApiExceptionTypes.valueOf(exceptionType);
			throw raiseException(url, request, serviceName, customErrorMessage, e, exceptionTypeName, 
					createErrorDetails(enablerName,fullErrorMsg,String.valueOf(e.getRawStatusCode())));
		}
	}
	
	/**
	 * methhod to create errorDEtails
	 * @param enablerName OF TYPE String
	 * @param fullErrorMessage OF TYPE String
	 * @param errorCode OF TYPE String
	 * @return ComponentErrorDetails of type ComponentErrorDetails
	 */
	
	default ComponentErrorDetails createErrorDetails(String enablerName, String fullErrorMessage, String errorCode){
		return new ComponentErrorDetails(enablerName,fullErrorMessage,errorCode);
	}

	default Exception raiseException(String url, Object request, String serviceName, String customErrorMessage,
			HttpStatusCodeException e, ApiExceptionTypes exceptionTypeName, final ComponentErrorDetails enablerError)
			 {
		Exception exp = null;
		switch (exceptionTypeName) {
		case ApiServiceException:
			exp = new ApiServiceException(
					StringUtils.isNoneEmpty(customErrorMessage) ? customErrorMessage : e.getMessage(),
					String.valueOf(e.getRawStatusCode()), serviceName, Arrays.asList(enablerError), e, url, request,
					null, ExceptionUtilApplication.ApiExceptionTypes.ApiServiceException);
			break;
		case ApiDBException:
			exp = new ApiDBException(
					StringUtils.isNoneEmpty(customErrorMessage) ? customErrorMessage : e.getMessage(),
					String.valueOf(e.getRawStatusCode()), serviceName, Arrays.asList(enablerError), e, url, request,
					null, ExceptionUtilApplication.ApiExceptionTypes.ApiDBException);
			break;
		case ApiBusinessError:
			exp = new ApiBusinessError(
					StringUtils.isNoneEmpty(customErrorMessage) ? customErrorMessage : e.getMessage(),
					String.valueOf(e.getRawStatusCode()), serviceName, Arrays.asList(enablerError), e, url, request,
					null, ExceptionUtilApplication.ApiExceptionTypes.ApiBusinessError);
			break;		
		default:
			exp = e;
			break;
		}
		return exp;
	}

	default boolean validCall(Map<String, Object> params) {
		final String str1 = params.containsKey("ENABLER_NAME") ? (String) params.get("ENABLER_NAME") : null;
		final String str2 = params.containsKey("SERVICE_NAME") ?  (String) params.get("SERVICE_NAME") : null;
		final String str3 = params.containsKey("EXCEPTION_TYPE") ? (String) params.get("EXCEPTION_TYPE") : null;
		return !(StringUtils.isEmpty(str1) || StringUtils.isEmpty(str2) || StringUtils.isEmpty(str3));
	}

	/**
	 * This method is used to handle a customer expcetion
	 * @param e instance of Exception
	 * @throws ApiException custom exception
	 * @throws IOException custom exception
	 */
	public default void handleCustomException(Exception e) throws ApiException, IOException {
		if (e instanceof HttpStatusCodeException && ((HttpStatusCodeException) e).getRawStatusCode() == 417) 
			throw new ObjectMapper().readValue(((HttpStatusCodeException) e).getResponseBodyAsString(),
						ApiException.class);		
	}
	
	/**
	 * This method adds more parameters to pass to calling method
	 * @param enablerName the enabler name
	 * @param serviceName the actual service name for enabler
	 * @param exceptionType the kind of exception to generate
	 * @param customErrorMessage over riddent method
	 * @param moreParams instance of Map
	 * @param log instance of Logger
	 * @return instance of Map
	 */
	public default Map<String,Object> packageParams(String enablerName,  
        	String serviceName, String exceptionType, String customErrorMessage,
        	Logger log, Map<String,Object> moreParams) {
		final Map<String,Object> output = new ConcurrentHashMap<>(4);
		if(null != enablerName)
			output.put("ENABLER_NAME", enablerName);
		if(null != serviceName)
			output.put("SERVICE_NAME", serviceName);
		if(null != exceptionType)
			output.put("EXCEPTION_TYPE", exceptionType);
		if(null != customErrorMessage)
			output.put("CUSTOM_ERROR_MSG", customErrorMessage);
		if(null != log)
			output.put("LOGGER", log);
		if(null != moreParams)
			output.putAll(moreParams);
		return output;
	}
	
	/**
	 * This method is used to call http get call
	 * @param clazz instance of response class type
	 * @param url instance of get endpoint
	 * @param exceptionTypeName instance of exception type name
	 * @param restTemplate instance of rest template
	 * @param objectMapper instance of object mapper
	 * @param uriVariables instance of uri variables
	 * @return instance of custom response class
	 * @throws Exception common exception
	 */
	public default <T> T getForEntity(Class<T> clazz, String url, ApiExceptionTypes exceptionTypeName, RestTemplate restTemplate,
			ObjectMapper objectMapper, Object... uriVariables) throws Exception {
        try {
            ResponseEntity<String> response = restTemplate.getForEntity(url, String.class, uriVariables);
            JavaType javaType = objectMapper.getTypeFactory().constructType(clazz);
            return readValue(response, objectMapper, javaType);
        } catch (HttpClientErrorException e) {
        	throw raiseException(url, null, null, null, e, exceptionTypeName, null);
        }
    }

	/**
	 * This method is to fetch a list using get endpoint
	 * @param clazz instance of response class type
	 * @param url instance of get endpoint
	 * @param exceptionTypeName instance of exception type name
	 * @param restTemplate instance of rest template
	 * @param objectMapper instance of object mapper
	 * @param uriVariables instance of uri variables
	 * @return instance of custom response class
	 * @throws Exception common exception
	 */
    public default <T> List<T> getForList(Class<T> clazz, String url,ApiExceptionTypes exceptionTypeName,RestTemplate restTemplate,
			ObjectMapper objectMapper, Object... uriVariables) throws Exception {
        try {
            ResponseEntity<String> response = restTemplate.getForEntity(url, String.class, uriVariables);
            CollectionType collectionType = objectMapper.getTypeFactory().constructCollectionType(List.class, clazz);
            return readValue(response, objectMapper, collectionType);
        } catch (HttpClientErrorException e) {
        	throw raiseException(url, null, null, null, e, exceptionTypeName, null);
        }
    }

    /**
     * This method is for post method operation
     * @param clazz instance of response class type
	 * @param url instance of get endpoint
	 * @param body instance of reponse body
	 * @param restTemplate instance of rest template
	 * @param objectMapper instance of object mapper
	 * @param uriVariables instance of uri variables
	 * @return instance of custom response class
	 * @throws Exception common exception
     */
    public default <T, R> T postForEntity(Class<T> clazz, String url, R body, RestTemplate restTemplate,
			ObjectMapper objectMapper, Object... uriVariables) throws Exception {
        HttpEntity<R> request = new HttpEntity<>(body);
        ResponseEntity<String> response = restTemplate.postForEntity(url, request, String.class, uriVariables);
        JavaType javaType = objectMapper.getTypeFactory().constructType(clazz);
        return readValue(response, objectMapper, javaType);
    }

    /**
     * This method is for put method operation
     * @param clazz instance of response class type
	 * @param url instance of get endpoint
	 * @param body instance of reponse body
	 * @param restTemplate instance of rest template
	 * @param objectMapper instance of object mapper
	 * @param uriVariables instance of uri variables
	 * @return instance of custom response class
	 * @throws Exception common exception
     */
    public default <T, R> T putForEntity(Class<T> clazz, String url, R body, RestTemplate restTemplate,
			ObjectMapper objectMapper,  Object... uriVariables) throws Exception {
        HttpEntity<R> request = new HttpEntity<>(body);
        ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.PUT, request, String.class, uriVariables);
        JavaType javaType = objectMapper.getTypeFactory().constructType(clazz);
        return readValue(response, objectMapper, javaType);
    }
    
    /**
     * This method is for delete method operation
     * @param clazz instance of response class type
	 * @param url instance of get endpoint
	 * @param exceptionTypeName instance of exception tupe
	 * @param restTemplate instance of rest template
	 * @param objectMapper instance of object mapper
	 * @param uriVariables instance of uri variables
	 * @return instance of custom response class
	 * @throws Exception common exception
     */
    public default void delete(String url, ApiExceptionTypes exceptionTypeName, RestTemplate restTemplate,
			ObjectMapper objectMapper, Object... uriVariables) throws Exception {
        try {
            restTemplate.delete(url, uriVariables);
        } catch (HttpClientErrorException e) {
        	throw raiseException(url, null, null, null, e, exceptionTypeName, null);
        }
    }

    /**
     * This is a method to read response as string and convert to proper response object
     * @param response instance of response as String
     * @param objectMapper instance of object mapper
     * @param javaType instance of JAVA type
     * @return custome object instance
     */
    default <T> T readValue(ResponseEntity<String> response, 
			ObjectMapper objectMapper,  JavaType javaType) {
        T result = null;
        if (response.getStatusCode() == HttpStatus.OK ||
                response.getStatusCode() == HttpStatus.CREATED) {
            try {
                result = objectMapper.readValue(response.getBody(), javaType);
            } catch (Exception e) {
            	logger.info(e.getMessage());
            }
        } else {
        	logger.info("No data found {}", response.getStatusCode());
        }
        return result;
    }

}
