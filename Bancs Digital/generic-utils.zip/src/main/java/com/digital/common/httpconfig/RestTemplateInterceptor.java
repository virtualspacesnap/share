package com.digital.common.httpconfig;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import javax.annotation.PostConstruct;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpRequest;
import org.springframework.http.client.ClientHttpRequestExecution;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.ClientHttpResponse;

/**
 * Description:This is the RestTemplateInterceptor class
 * 
 * @author TCS
 *
 */
public class RestTemplateInterceptor implements ClientHttpRequestInterceptor {

	private static final Logger log = LoggerFactory.getLogger(RestTemplateInterceptor.class);
	private static final String UTF8 = "UTF-8";
	private Boolean doForceLogging = false;
	private static final String LINE_SEPRATOR = System.lineSeparator();

	@Autowired
	private Environment env;

	/**
	 * Description: prepare config method
	 * 
	 */
	@PostConstruct
	public void prepareConfig() {
		doForceLogging = StringUtils.equalsIgnoreCase("Y",
				env.getProperty("FORCE_LOG_AROUND_CALL"));
	}

	@Override
	public ClientHttpResponse intercept(HttpRequest request, byte[] body, ClientHttpRequestExecution execution)
			throws IOException {
		this.traceRequest(request, body);
		ClientHttpResponse response = execution.execute(request, body);
		this.traceResponse(response);
		return response;
	}

	private void traceRequest(HttpRequest request, byte[] body){
		try {
			StringBuilder sb = new StringBuilder(
					"===========================request begin================================================");
			sb.append(LINE_SEPRATOR);
			sb.append("URI         : {}").append(request.getURI());
			sb.append(LINE_SEPRATOR);
			sb.append("Method      : {}").append(request.getMethod());
			sb.append(LINE_SEPRATOR);
			sb.append("Headers     : {}").append(request.getHeaders());
			sb.append(LINE_SEPRATOR);
			sb.append("Request body: {}").append(new String(body, UTF8));
			sb.append(LINE_SEPRATOR);
			sb.append("==========================request end================================================");
			if (doForceLogging)
				log.info(sb.toString());
			else
				log.debug(sb.toString());
			sb.setLength(0);
		} catch (Exception e) {
			log.debug("LOG EXCEPTION", e);
		}
	}

	private void traceResponse(ClientHttpResponse response) {
		try {
			StringBuilder inputStringBuilder = new StringBuilder();
			BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(response.getBody(), UTF8));
			String line = bufferedReader.readLine();
			while (line != null) {
				inputStringBuilder.append(line);
				inputStringBuilder.append('\n');
				line = bufferedReader.readLine();
			}
			StringBuilder sb = new StringBuilder(
					"===========================response begin================================================");
			sb.append(LINE_SEPRATOR);
			sb.append("Status code  : {}").append(response.getStatusCode());
			sb.append(LINE_SEPRATOR);
			sb.append("Status text  : {}").append(response.getStatusText());
			sb.append(LINE_SEPRATOR);
			sb.append("Headers      : {}").append(response.getHeaders());
			sb.append(LINE_SEPRATOR);
			sb.append("Response body: {}").append(inputStringBuilder.toString());
			sb.append(LINE_SEPRATOR);
			sb.append("==========================response end================================================");
			if (doForceLogging)
				log.info(sb.toString());
			else
				log.debug(sb.toString());
			sb.setLength(0);
		} catch (Exception e) {
			log.error("LOG EXCEPTION", e);
		}
	}
}
