/**
 * 
 */
package com.digital.common.cache;

import java.lang.ref.SoftReference;
import java.util.concurrent.Delayed;
import java.util.concurrent.TimeUnit;

/**
 * This class in used to play host for cache
 * @author TCS
 *
 */
public class CacheModel implements Delayed {

	private final String key;
    private final SoftReference<Object> reference;
    private final long expiryTime;

    public CacheModel(String key, SoftReference<Object> reference, long expiryTime) {
        this.key = key;
        this.reference = reference;
        this.expiryTime = expiryTime;
    }

    public String getKey() {
        return key;
    }

    public SoftReference<Object> getReference() {
        return reference;
    }

    @Override
    public long getDelay(TimeUnit unit) {
        return unit.convert(expiryTime - System.currentTimeMillis(), TimeUnit.MILLISECONDS);
    }

    @Override
    public int compareTo(Delayed o) {
        return Long.compare(expiryTime, ((CacheModel) o).expiryTime);
    }	
	
}
