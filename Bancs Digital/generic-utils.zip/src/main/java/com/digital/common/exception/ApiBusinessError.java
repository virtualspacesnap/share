package com.digital.common.exception;

import java.util.List;

import com.digital.common.exception.ExceptionUtilApplication.ApiExceptionTypes;


public class ApiBusinessError extends ApiException {

	private static final long serialVersionUID = 8599457574636803643L;

	public ApiBusinessError(String errMsg) {
		super(errMsg);
	}
	
	public ApiBusinessError(String errCode, String errMsg) {
		super(errCode, errMsg);
	}
	
	public ApiBusinessError(String errMsg, String errCode, String serviceName,
			List<ComponentErrorDetails> enablerErrors,
			Throwable originalException, String endpoint, Object requestObj, Object responseObj, ApiExceptionTypes exceptionType) {
		super(errMsg, errCode, serviceName,
				enablerErrors, originalException, endpoint, requestObj, responseObj, exceptionType);
	}

}
