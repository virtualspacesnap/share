package com.digital.common.httpconfig;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpHost;
import org.apache.http.client.HttpClient;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.conn.routing.HttpRoute;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.http.client.BufferingClientHttpRequestFactory;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.util.CollectionUtils;
import org.springframework.web.client.DefaultResponseErrorHandler;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Supports both HTTP and HTTPS - Uses a connection pool to re-use connections
 * and save overhead of creating connections.
 */
@Configuration
@ConditionalOnProperty(value = "http.configapply", havingValue = "Y", matchIfMissing = false)
public class HttpClientConfig implements AutoCloseable {
	
	// Determines the timeout in milliseconds until a connection is established.
	@Value("${http.connect_timeout}")
	private String connectTimeout;

	// The timeout when requesting a connection from the connection manager.
	@Value("${http.request_timeout}")
	private String requestTimeout;

	// The timeout for waiting for data
	@Value("${http.socket_timeout}")
	private String socketTimeout;

	@Value("${http.max_connection}")
	private String maxTotalConnections;

	@Value("${http.default_max_per_route}")
	private String defaultMaxPerRoute;

	@Value("${http.max_per_route}")
	private String maxPerRoute;

	@Value("${http.configapply}")
	private String applyHttpConfig;

	@Value("${http.addInterceptor}")
	private String addInterceptor;

	@Value("${server.port}")
	private String serverPort;

	@Value("${http.host}")
	private String httpHost;

	private PoolingHttpClientConnectionManager result = new PoolingHttpClientConnectionManager();
	
	/**
	 * Created Pooling HTTP Clinet Conection Manager
	 * @return PoolingHttpClientConnectionManager
	 */
	public PoolingHttpClientConnectionManager getHttpClientConnectionManager() {
		return this.result;
	}

	/**
	 * Method to return instance of PoolingHttpClientConnectionManager
	 * @return instance of PoolingHttpClientConnectionManager
	 */
	@Bean
	public PoolingHttpClientConnectionManager poolingHttpClientConnectionManager() {
		result.setMaxTotal(Integer.parseInt(maxTotalConnections));
		result.setDefaultMaxPerRoute(Integer.parseInt(defaultMaxPerRoute));
		HttpHost host = new HttpHost(httpHost, Integer.parseInt(serverPort), "http");
		result.setMaxPerRoute(new HttpRoute(host), Integer.parseInt(maxPerRoute));
		return result;
	}

	/**
	 * Method to return instance of RequestConfig
	 * @return instance of RequestConfig
	 */
	@Bean(name = "commonHttpConfig")
	public RequestConfig requestConfig() {
		return RequestConfig.custom().setConnectionRequestTimeout(Integer.parseInt(requestTimeout))
				.setConnectTimeout(Integer.parseInt(connectTimeout)).setSocketTimeout(Integer.parseInt(socketTimeout))
				.build();
	}

	/**
	 * Method to create a new CloseableHttpClient
	 * @param poolingHttpClientConnectionManager instance of PoolingHttpClientConnectionManager
	 * @param requestConfig instance of RequestConfig
	 * @return instance of CloseableHttpClient
	 */
	@Bean(name = "commonHttpClient")
	@Primary
	public CloseableHttpClient httpClient(PoolingHttpClientConnectionManager poolingHttpClientConnectionManager,
			RequestConfig requestConfig) {
		return HttpClientBuilder
				.create()
				.setConnectionManager(poolingHttpClientConnectionManager)
				.evictExpiredConnections()
				.setDefaultRequestConfig(requestConfig).build();
	}

	/**
	 * Method that creates a new rest template
	 * @param httpClient instance of HttpClient
	 * @return instance of RestTemplate
	 */
	@Bean(name = "restTemplate3")
	public RestTemplate restTemplate(HttpClient httpClient) {
		HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory();
		requestFactory.setHttpClient(httpClient);
		RestTemplate template = StringUtils.equalsIgnoreCase(this.applyHttpConfig, "Y")
				? new RestTemplate(new BufferingClientHttpRequestFactory(requestFactory))
				: new RestTemplate(new BufferingClientHttpRequestFactory(new SimpleClientHttpRequestFactory()));
		template.setErrorHandler(new DefaultResponseErrorHandler());
		if (StringUtils.equalsIgnoreCase(this.addInterceptor, "Y")) {
			List<ClientHttpRequestInterceptor> interceptors = template.getInterceptors();
			if (CollectionUtils.isEmpty(interceptors))
				interceptors = new ArrayList<>(1);
			interceptors.add(new RestTemplateInterceptor());
			template.setInterceptors(interceptors);
		}
		return template;
	}


	/**
	 * This creates a simple rest template with no http connection pooling
	 * @return
	 */
	@Bean(name = "restTemplate1")
	public RestTemplate defaultRestTemplate(){
		return new RestTemplate();
	}
	
	
	/**
	 * Method that creates a new rest template with http connection pooling + removing null from requests
	 * @param httpClient instance of HttpClient
	 * @return instance of RestTemplate
	 */
	@Bean(name = "restTemplate2")
	public RestTemplate restEnhancedTemplate(HttpClient httpClient) {
		HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory();
		requestFactory.setHttpClient(httpClient);
		RestTemplate template = StringUtils.equalsIgnoreCase(this.applyHttpConfig, "Y")
				? new RestTemplate(new BufferingClientHttpRequestFactory(requestFactory))
				: new RestTemplate(new BufferingClientHttpRequestFactory(new SimpleClientHttpRequestFactory()));
		template.setErrorHandler(new DefaultResponseErrorHandler());
		
		ObjectMapper mapper = new ObjectMapper();
        mapper.setSerializationInclusion(Include.NON_NULL);
        mapper.setSerializationInclusion(Include.NON_EMPTY);
        mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
        mapper.configure(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true);
        MappingJackson2HttpMessageConverter converter = new MappingJackson2HttpMessageConverter();
        converter.setObjectMapper(mapper);
        template.getMessageConverters().add(0, converter);
		
		if (StringUtils.equalsIgnoreCase(this.addInterceptor, "Y")) {
			List<ClientHttpRequestInterceptor> interceptors = template.getInterceptors();
			if (CollectionUtils.isEmpty(interceptors))
				interceptors = new ArrayList<>(1);
			interceptors.add(new RestTemplateInterceptor());
			template.setInterceptors(interceptors);
		}
		return template;
	}
	

	/* (non-Javadoc)
	 * @see java.lang.AutoCloseable#close()
	 */
	@Override
	public void close() throws Exception {
		result.close();
	}
	
}
