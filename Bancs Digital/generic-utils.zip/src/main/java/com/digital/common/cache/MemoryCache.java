/**
 * 
 */
package com.digital.common.cache;

/**
 * This class contains method for memory cache
 * @author TCS
 *
 */
public interface MemoryCache {

	void add(String source, String key, Object value, long periodInMillis);

	void remove(String source, String key);

	Object get(String source, String key);

	void clear();

	long size();

}
