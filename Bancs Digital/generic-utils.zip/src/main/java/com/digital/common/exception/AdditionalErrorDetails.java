package com.digital.common.exception;

import java.io.Serializable;

/**
 * AdditionalErrorDetails
 */
import com.fasterxml.jackson.databind.ObjectMapper;

@SuppressWarnings("serial")
public class AdditionalErrorDetails implements Serializable {

	private String serviceName = null;

	private String endPoint = null;

	private String raisedOn = null;

	private String request = null;

	private String response = null;

	private String exceptionStackTrace = null;

	private String exceptionType = null;

	private static final ObjectMapper mapper = new ObjectMapper();

	public AdditionalErrorDetails(String serviceName, String endPoint, String raisedOn, Object request, Object response,
			String exceptionStackTrace, String exceptionType) {
		super();
		this.serviceName = serviceName;
		this.endPoint = endPoint;
		this.raisedOn = raisedOn;
		this.request = this.convert(request);
		this.response = this.convert(response);
		this.exceptionStackTrace = exceptionStackTrace;
		this.exceptionType = exceptionType;
	}

	private String convert(Object obj) {
		String output = null;
		try {
			output = mapper.writeValueAsString(obj);
		} catch (final Exception e) {
			e.printStackTrace();
		}
		return output;
	}
	
	

	public String getServiceName() {
		return serviceName;
	}

	public String getEndPoint() {
		return endPoint;
	}

	public static ObjectMapper getMapper() {
		return mapper;
	}

	public String getRaisedOn() {
		return raisedOn;
	}

	public String getRequest() {
		return request;
	}

	public String getResponse() {
		return response;
	}

	public String getExceptionStackTrace() {
		return exceptionStackTrace;
	}

	public String getExceptionType() {
		return exceptionType;
	}

}
