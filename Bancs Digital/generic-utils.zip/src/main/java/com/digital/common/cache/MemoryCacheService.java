/**
 * 
 */
package com.digital.common.cache;

import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.lang.ref.SoftReference;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.DelayQueue;

/**
 * This class contains service methods for in memory cache service
 * 
 * @author TCS
 *
 */
@Component
public class MemoryCacheService implements MemoryCache {

	private final ConcurrentHashMap<String, SoftReference<Object>> cache = new ConcurrentHashMap<>();
	private final DelayQueue<CacheModel> cleaningUpQueue = new DelayQueue<>();

	public MemoryCacheService() {
		Thread cleanerThread = new Thread(() -> {
			while (!Thread.currentThread().isInterrupted()) {
				try {
					CacheModel delayedCacheObject = cleaningUpQueue.take();
					cache.remove(delayedCacheObject.getKey(), delayedCacheObject.getReference());
				} catch (InterruptedException e) {
					Thread.currentThread().interrupt();
				}
			}
		});
		cleanerThread.setName("MEMORY-CACHE-CLEANER");
		cleanerThread.setDaemon(true);
		cleanerThread.start();
	}

	private String getCacheKey(String source, String key) {
		return new StringBuffer(source).append("~~").append(key).toString();
	}

	@Override
	public void add(String source, String key, Object value, long periodInMillis) {
		if (StringUtils.isEmpty(key) || StringUtils.isEmpty(source))
			return;

		final String cacheKey = this.getCacheKey(source, key);
		if (Objects.isNull(value))
			this.cache.remove(cacheKey);
		else {
			long expiryTime = System.currentTimeMillis() + periodInMillis;
			SoftReference<Object> reference = new SoftReference<>(value);
			cache.put(cacheKey, reference);
			if (periodInMillis > 0)
				cleaningUpQueue.put(new CacheModel(cacheKey, reference, expiryTime));
		}
	}

	@Override
	public void remove(String source, String key) {
		cache.remove(this.getCacheKey(source, key));
	}

	@Override
	public Object get(String source, String key) {
		return Optional.ofNullable(cache.get(this.getCacheKey(source, key))).map(SoftReference::get).orElse(null);
	}

	@Override
	public void clear() {
		cache.clear();
	}

	@Override
	public long size() {
		return cache.size();
	}

}
