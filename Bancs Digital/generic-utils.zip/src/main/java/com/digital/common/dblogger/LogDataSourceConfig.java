package com.digital.common.dblogger;

import java.sql.Connection;
import java.sql.SQLException;
import javax.sql.DataSource;

import org.apache.commons.dbcp2.ConnectionFactory;
import org.apache.commons.dbcp2.DriverManagerConnectionFactory;
import org.apache.commons.dbcp2.PoolableConnection;
import org.apache.commons.dbcp2.PoolableConnectionFactory;
import org.apache.commons.dbcp2.PoolingDataSource;
import org.apache.commons.pool2.ObjectPool;
import org.apache.commons.pool2.impl.GenericObjectPool;
import org.apache.logging.log4j.core.appender.db.jdbc.ConnectionSource;

/**
 * This class contains method to create a poolable connection factory
 * 
 * @author TCS
 *
 */
public class LogDataSourceConfig implements ConnectionSource {
	
	private DataSource dataSource;

	private LogDataSourceConfig() {
		super();
	}

	/**
	 * Argumented constructor
	 * 
	 * @param url
	 *            instance of URL
	 * @param userName
	 *            instance of USERNAME
	 * @param driver
	 *            driver name
	 * @param password
	 *            instance of PASSWORD
	 * @param validationQuery
	 *            instance of VALIDATIONQUERY
	 * @throws ClassNotFoundException
	 *             exception
	 */
	public LogDataSourceConfig(String url, String userName, String password, String validationQuery, String driver)
			throws ClassNotFoundException {
		this();
		Class.forName(driver);
		ConnectionFactory connectionFactory = new DriverManagerConnectionFactory(url, userName, password);
		PoolableConnectionFactory poolableConnectionFactory = new PoolableConnectionFactory(connectionFactory, null);
		poolableConnectionFactory.setValidationQuery(validationQuery);
		poolableConnectionFactory.setDefaultAutoCommit(false);
		poolableConnectionFactory.setDefaultTransactionIsolation(Connection.TRANSACTION_READ_COMMITTED);
		ObjectPool<PoolableConnection> connectionPool = new GenericObjectPool<>(poolableConnectionFactory);
		poolableConnectionFactory.setPool(connectionPool);
		this.dataSource = new PoolingDataSource<>(connectionPool);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.apache.logging.log4j.core.appender.db.jdbc.ConnectionSource#
	 * getConnection()
	 */
	@Override
	public Connection getConnection() throws SQLException {
		return dataSource.getConnection();
	}

	@Override
	public State getState() {
		return null;
	}

	@Override
	public void initialize() {
		//no arg
	}

	@Override
	public void start() {
		//no arg
	}

	@Override
	public void stop() {
		//no arg		
	}

	@Override
	public boolean isStarted() {
		return this.dataSource != null;
	}

	@Override
	public boolean isStopped() {
		return this.dataSource == null;
	}
}
