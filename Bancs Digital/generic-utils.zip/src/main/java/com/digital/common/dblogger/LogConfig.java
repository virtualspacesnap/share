package com.digital.common.dblogger;

import javax.annotation.PostConstruct;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.core.Logger;
import org.apache.logging.log4j.core.appender.db.jdbc.ColumnConfig;
import org.apache.logging.log4j.core.appender.db.jdbc.JdbcAppender;
import org.apache.logging.log4j.core.filter.ThresholdFilter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;

import com.digital.common.exception.ExceptionUtilApplication;


/**
 * This class contains method to dynamically create an appender to asynchronous
 * logger
 * 
 * @author TCS
 *
 */
@Configuration
@ConditionalOnProperty(value = "log.datasource.enable", havingValue = "Y", matchIfMissing = false)
public class LogConfig {
	@Autowired
	private Environment env;

	private static final String TRUE = "true";
	private static final String FALSE = "false";
	private static final String DEBUG = "DEBUG";
	private static final String INFO = "INFO";
	private static final String WARN = "WARN";
	private static final String TRACE = "TRACE";
	private static final String ERROR = "ERROR";
	private static final String DBERR_PUSH = "DBERR_PUSH";
	
	/**
	 * Method that is called on startup
	 */
	@PostConstruct
	public void onStartUp() {
		if (StringUtils.equalsIgnoreCase("Y", env.getProperty("log.datasource.enable"))) {
			String url = env.getProperty("log.datasource.url");
			String userName = env.getProperty("log.datasource.username");
			String password = env.getProperty("log.datasource.password");
			String validationQuery = env.getProperty("log.datasource.validationquery");
			String driver = env.getProperty("log.datasource.driver");

			// Create a new connectionSource build from the Spring properties
			LogDataSourceConfig connectionSource = null;
			try {
				connectionSource = new LogDataSourceConfig(url, userName, password, validationQuery, driver);
			} catch (Exception e) {
				System.err.println(e.getStackTrace());
			}

			// This is the mapping between the columns in the table and what to
			// insert in it.
			ColumnConfig[] columnConfigs = new ColumnConfig[8];
			columnConfigs[0] = ColumnConfig.createColumnConfig(null, "THREAD_NAME", "%t", null, null, FALSE, null);
			columnConfigs[1] = ColumnConfig.createColumnConfig(null, "LOG_DATE", null, null, TRUE, null, null);
			columnConfigs[2] = ColumnConfig.createColumnConfig(null, "LOGGER", "%logger", null, null, FALSE, null);
			columnConfigs[3] = ColumnConfig.createColumnConfig(null, "LOG_LEVEL", "%level", null, null, FALSE, null);
			columnConfigs[4] = ColumnConfig.createColumnConfig(null, "MESSAGE", "%message", null, null, FALSE, null);
			columnConfigs[5] = ColumnConfig.createColumnConfig(null, "TIME", "%d", null, null, FALSE, null);
			columnConfigs[6] = ColumnConfig.createColumnConfig(null, "FILE_VALUE", "%l", null, null, FALSE, null);
			columnConfigs[7] = ColumnConfig.createColumnConfig(null, "CORRELATION_ID", "%X{correlationId}", null, null,
					FALSE, null);

			// filter for the appender to keep only errors
			ThresholdFilter filter = null;
			switch (env.getProperty("log.datasource.loglevel")) {
			case DEBUG:
				filter = ThresholdFilter.createFilter(Level.DEBUG, null, null);
				break;
			case INFO:
				filter = ThresholdFilter.createFilter(Level.INFO, null, null);
				break;
			case WARN:
				filter = ThresholdFilter.createFilter(Level.WARN, null, null);
				break;
			case TRACE:
				filter = ThresholdFilter.createFilter(Level.TRACE, null, null);
				break;
			case ERROR:
				filter = ThresholdFilter.createFilter(Level.ERROR, null, null);
				break;
			case DBERR_PUSH:
				filter = ThresholdFilter.createFilter(ExceptionUtilApplication.DBERR_PUSH, null, null);
				break;
			default:
				filter = ThresholdFilter.createFilter(Level.ALL, null, null);
				break;
			}

			// The creation of the new database appender passing:
			// - the name of the appender
			// - ignore exceptions encountered when appending events are logged
			// - the filter created previously
			// - the connectionSource,
			// - log buffer size,
			// - the name of the table
			// - the config of the columns.
			JdbcAppender appender = JdbcAppender.createAppender("DB", TRUE, filter, connectionSource,
					env.getProperty("log.datasource.logBufferSize"), env.getProperty("log.datasource.tableName"),
					columnConfigs);

			appender.start();
			Logger logger = (Logger) LogManager.getLogger(env.getProperty("log.datasource.asynclogger"));
			logger.addAppender(appender);

			((Logger) LogManager.getRootLogger()).addAppender(appender);
		}
	}
}
