package com.digital.common.exception;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@ControllerAdvice
public class ApiExceptionandlerAdvice extends ResponseEntityExceptionHandler {
	
	@Autowired
	private Environment env;

	@ExceptionHandler({ApiException.class, ApiServiceException.class, ApiBusinessError.class,
		ApiDBException.class})
	@ResponseStatus(value = HttpStatus.EXPECTATION_FAILED)
	public @ResponseBody BaseResponseObject handleException(final ApiException ex, final HttpServletRequest request) {
		final String additionalDetails = env.getProperty("additional.exception.details");
		if (StringUtils.equalsAnyIgnoreCase(additionalDetails, "Y")) 
			return this.createResponseObject(ex.getErrMsg(), ex.getErrCode(), ex.getEnablerErrors(), ex.getServiceName(), 
					ex.getEndpoint(), ex.getRaisedOn(), ex.getRequestObj(), ex.getResponseObj(), ex.getOriginalException(), ex.getExceptionType());
		else
			return this.createResponseObject(ex.getErrMsg(), ex.getErrCode(), ex.getEnablerErrors(), ex.getServiceName(), 
					ex.getEndpoint(), ex.getRaisedOn(), null, null, null, ex.getExceptionType());
	}

	@ExceptionHandler(Throwable.class)
	@ResponseBody
	public final ResponseEntity<BaseResponseObject> handleAllExceptions(Exception ex, WebRequest request) {
		BaseResponseObject error = new BaseResponseObject(ex.getLocalizedMessage(), HttpStatus.INTERNAL_SERVER_ERROR.name());
		return new ResponseEntity<>(error, HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	
	private BaseResponseObject createResponseObject(String errMsg, String errCode,
			List<ComponentErrorDetails> enablerErrors, String serviceName, String endPoint, String raisedOn,
			Object requestObj, Object responseObj, Throwable originalException, String exceptionType) {
		BaseResponseObject response = new BaseResponseObject(errMsg, errCode);
		response.setBaseErrorMsg(new ArrayList<>(0));
		if (null != enablerErrors)
			for (ComponentErrorDetails error : enablerErrors)
				response.getBaseErrorMsg().add(
						new BaseErrorMsg(error.getComponentName(), error.getComponentErrCode(), error.getComponentErrMsg()));
		response.setAdditionalErrorDetails(new AdditionalErrorDetails(serviceName, endPoint, raisedOn, requestObj,
				responseObj, null != originalException ? ExceptionUtils.getStackTrace(originalException) : null, exceptionType));
		return response;
	}

}
