package com.digital.common.exception;

import java.util.List;

import com.digital.common.exception.ExceptionUtilApplication.ApiExceptionTypes;


public class ApiDBException extends ApiException {

	private static final long serialVersionUID = 8599457574636803643L;

	public ApiDBException(String errMsg) {
		super(errMsg);
	}
	
	public ApiDBException(String errCode, String errMsg) {
		super(errCode, errMsg);
	}
	
	public ApiDBException(String errMsg, String errCode, String serviceName,
			List<ComponentErrorDetails> enablerErrors,
			Throwable originalException, String endpoint, Object requestObj, Object responseObj, ApiExceptionTypes exceptionType) {
		super(errMsg, errCode, serviceName,
				enablerErrors, originalException, endpoint, requestObj, responseObj, exceptionType);
	}

}
