package com.digital.common.exception;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

@SuppressWarnings("serial")
public class BaseErrorMsg implements Serializable {
	@JsonProperty("componentName")
	private String componentName = null;

	@JsonProperty("friendlyMsg")
	private String friendlyMsg = null;

	@JsonProperty("errorCode")
	private String errorCode = null;

	@JsonProperty("errorMsg")
	private String errorMsg = null;

	public BaseErrorMsg(String componentName, String friendlyMsg, String errorCode, String errorMsg) {
		super();
		this.componentName = componentName;
		this.friendlyMsg = friendlyMsg;
		this.errorCode = errorCode;
		this.errorMsg = errorMsg;
	}

	public BaseErrorMsg(String componentName, String errorCode, String errorMsg) {
		super();
		this.componentName = componentName;
		this.errorCode = errorCode;
		this.errorMsg = errorMsg;
	}

	public String getFriendlyMsg() {
		return friendlyMsg;
	}

	public void setFriendlyMsg(String friendlyMsg) {
		this.friendlyMsg = friendlyMsg;
	}

	public String getEnablerName() {
		return componentName;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public String getErrorMsg() {
		return errorMsg;
	}

	
	
	
}
