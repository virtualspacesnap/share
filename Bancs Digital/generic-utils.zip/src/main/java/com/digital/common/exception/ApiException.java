/**
 * 
 */
package com.digital.common.exception;

import java.io.InputStream;
import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;
import java.util.Objects;
import java.util.Properties;

import org.apache.commons.lang3.exception.ExceptionUtils;

import com.digital.common.exception.ExceptionUtilApplication.ApiExceptionTypes;


/**
 * This is the parent class for Exception
 * @author TCS
 *
 */
public class ApiException extends Exception implements Serializable {

	private static final long serialVersionUID = 9903380767L;
	
	private String errMsg = null;
	private String errCode = null;
	private List<ComponentErrorDetails> enablerErrors = null;
	private String serviceName = null;
	private String raisedOn = null;
	private Throwable originalException = null;
	private String endpoint = null;
	private Object requestObj = null;
	private Object responseObj = null;
	private String exceptionStackTrace = null;
	private String exceptionType = null;
	
	public static Properties messages = null;
	private static final String ERROR_PROP_FILE = "api_error_message.properties";
	
	
	static {
		if (messages == null) {
			try (InputStream input = ApiException.class.getClassLoader().getResourceAsStream(ERROR_PROP_FILE)) {
	            Properties prop = new Properties();
	            if (input != null) {
	            	prop.load(input);
	            	messages = prop;
	            }	            
			} catch (Exception ex) {
	            ex.printStackTrace();
	        }
		}
	}
	
	private ApiException() {
		super();
	}
	
	public ApiException(String errMsg) {
		this();
		this.errMsg = errMsg;
	}
	
	public ApiException(String errCode, String errMsg) {
		this();
		this.errMsg = errMsg;
		this.errCode = errCode;
	}
	
	public ApiException(String errMsg, String errCode, String serviceName,
			List<ComponentErrorDetails> enablerErrors,
			Throwable originalException, String endpoint, Object requestObj, Object responseObj, ApiExceptionTypes exceptionType) {
		this();
		this.errMsg = null != messages && messages.containsKey(errMsg) ? messages.getProperty(errMsg) : errMsg;
		this.errCode = errCode;
		this.enablerErrors = enablerErrors;
		this.serviceName = serviceName;
		this.raisedOn = String.valueOf(new Timestamp(System.currentTimeMillis()));
		this.originalException = originalException;
		this.endpoint = endpoint;
		this.requestObj = requestObj;
		this.responseObj = responseObj;
		this.exceptionStackTrace = !Objects.isNull(originalException) ? ExceptionUtils.getStackTrace(originalException) : null;
		this.exceptionType = !Objects.isNull(exceptionType)? exceptionType.name() : null;
	}

	/**
	 * @return the serialversionuid
	 */
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	/**
	 * @return the errMsg
	 */
	public String getErrMsg() {
		return errMsg;
	}

	/**
	 * @return the errCode
	 */
	public String getErrCode() {
		return errCode;
	}

	/**
	 * @return the serviceName
	 */
	public String getServiceName() {
		return serviceName;
	}

	/**
	 * @return the raisedOn
	 */
	public String getRaisedOn() {
		return raisedOn;
	}

	/**
	 * @return the originalException
	 */
	public Throwable getOriginalException() {
		return originalException;
	}

	/**
	 * @return the endpoint
	 */
	public String getEndpoint() {
		return endpoint;
	}

	/**
	 * @return the requestObj
	 */
	public Object getRequestObj() {
		return requestObj;
	}

	/**
	 * @return the responseObj
	 */
	public Object getResponseObj() {
		return responseObj;
	}

	/**
	 * @return the exceptionStackTrace
	 */
	public String getExceptionStackTrace() {
		return exceptionStackTrace;
	}

	/**
	 * @return the exceptionType
	 */
	public String getExceptionType() {
		return exceptionType;
	}

	/**
	 * 
	 * @return list of customer enabler error details object
	 */
	public List<ComponentErrorDetails> getEnablerErrors() {
		return enablerErrors;
	}
	

	/**
	 * Set the enabler Errors
	 * @param enablerErrors instance of enabler errors
	 */
	public void setEnablerErrors(List<ComponentErrorDetails> enablerErrors) {
		this.enablerErrors = enablerErrors;
	}
	
	
}

