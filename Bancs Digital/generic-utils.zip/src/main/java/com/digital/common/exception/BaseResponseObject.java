package com.digital.common.exception;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * BaseResponseObject
 */
@SuppressWarnings("serial")
public class BaseResponseObject implements Serializable {
	@JsonProperty("message")
	private String message = null;

	@JsonProperty("statusCode")
	private String statusCode = null;

	@JsonProperty("baseErrorMsg")
	private List<BaseErrorMsg> baseErrorMsg = new ArrayList<BaseErrorMsg>();

	@JsonProperty("additionalErrorDetails")
	private AdditionalErrorDetails additionalErrorDetails = null;

	public BaseResponseObject(String message, String statusCode) {
		super();
		this.message = message;
		this.statusCode = statusCode;
	}

	public List<BaseErrorMsg> getBaseErrorMsg() {
		return baseErrorMsg;
	}

	public void setBaseErrorMsg(List<BaseErrorMsg> baseErrorMsg) {
		this.baseErrorMsg = baseErrorMsg;
	}

	public AdditionalErrorDetails getAdditionalErrorDetails() {
		return additionalErrorDetails;
	}

	public void setAdditionalErrorDetails(AdditionalErrorDetails additionalErrorDetails) {
		this.additionalErrorDetails = additionalErrorDetails;
	}

	public String getMessage() {
		return message;
	}

	public String getStatusCode() {
		return statusCode;
	}

}
