package com.digital.common.exception;

public class ComponentErrorDetails {
	
	private String componentName = null;
	private String componentErrMsg = null;
	private String componentErrCode = null;
	
	public String getComponentName() {
		return componentName;
	}
	public String getComponentErrMsg() {
		return componentErrMsg;
	}
	public String getComponentErrCode() {
		return componentErrCode;
	}
	
	public ComponentErrorDetails(String componentName, String componentErrMsg, String componentErrCode) {
		this();
		this.componentName = componentName;
		this.componentErrMsg = componentErrMsg;
		this.componentErrCode = componentErrCode;
	}
	
	public ComponentErrorDetails() {		
	}
	
	@Override
	public String toString() {
		return "ComponentErrorDetails [componentName=" + componentName + ", componentErrMsg=" + componentErrMsg
				+ ", componentErrCode=" + componentErrCode + "]";
	}
	
	
	
	
}
